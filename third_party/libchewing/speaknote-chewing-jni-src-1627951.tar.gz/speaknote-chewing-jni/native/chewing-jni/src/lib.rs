//! JNI bindings for `app.speaknote.ime.chewing.ChewingNative`.
//!
//! Thin wrapper over the libchewing C API. Every function takes the raw
//! context pointer created by `nativeCreate`. All calls happen on the IME
//! main thread, so no locking is done here.

use std::ffi::{c_char, CStr, CString};
use std::ptr;

use chewing_capi::candidates::*;
use chewing_capi::globals::*;
use chewing_capi::input::*;
use chewing_capi::layout::chewing_set_KBType;
use chewing_capi::output::*;
use chewing_capi::setup::{chewing_delete, chewing_new2, chewing_Reset, ChewingContext};
use jni::objects::{JClass, JObject, JString};
use jni::sys::{jboolean, jint, jlong, jobjectArray, jstring, JNI_FALSE, JNI_TRUE};
use jni::JNIEnv;

fn ctx(ptr: jlong) -> *mut ChewingContext {
    ptr as *mut ChewingContext
}

fn cstr_to_string(p: *const c_char) -> String {
    if p.is_null() {
        return String::new();
    }
    unsafe { CStr::from_ptr(p) }.to_string_lossy().into_owned()
}

fn new_jstring(env: &mut JNIEnv, s: &str) -> jstring {
    match env.new_string(s) {
        Ok(js) => js.into_raw(),
        Err(_) => ptr::null_mut(),
    }
}

#[no_mangle]
pub extern "system" fn Java_app_speaknote_ime_chewing_ChewingNative_nativeCreate(
    mut env: JNIEnv,
    _class: JClass,
    sys_path: JString,
    user_path: JString,
) -> jlong {
    let sys: String = match env.get_string(&sys_path) {
        Ok(s) => s.into(),
        Err(_) => return 0,
    };
    let user: String = match env.get_string(&user_path) {
        Ok(s) => s.into(),
        Err(_) => return 0,
    };
    let (Ok(sys_c), Ok(user_c)) = (CString::new(sys), CString::new(user)) else {
        return 0;
    };
    let c = unsafe { chewing_new2(sys_c.as_ptr(), user_c.as_ptr(), None, ptr::null_mut()) };
    if c.is_null() {
        return 0;
    }
    unsafe {
        chewing_set_KBType(c, 0); // KB_DEFAULT (Daqian / standard layout)
        chewing_set_candPerPage(c, 10);
        chewing_set_maxChiSymbolLen(c, 20);
        chewing_set_spaceAsSelection(c, 0);
        chewing_set_escCleanAllBuf(c, 1);
        chewing_set_autoShiftCur(c, 1);
        chewing_set_phraseChoiceRearward(c, 1);
        chewing_set_addPhraseDirection(c, 1);
    }
    c as jlong
}

#[no_mangle]
pub extern "system" fn Java_app_speaknote_ime_chewing_ChewingNative_nativeDestroy(
    _env: JNIEnv,
    _class: JClass,
    p: jlong,
) {
    if p != 0 {
        unsafe { chewing_delete(ctx(p)) };
    }
}

#[no_mangle]
pub extern "system" fn Java_app_speaknote_ime_chewing_ChewingNative_nativeReset(
    _env: JNIEnv,
    _class: JClass,
    p: jlong,
) {
    unsafe { chewing_Reset(ctx(p)) };
}

/// key: ASCII code for bopomofo keys (standard layout), or one of the
/// special codes below.
pub const KEY_SPACE: jint = -1;
pub const KEY_BACKSPACE: jint = -2;
pub const KEY_ENTER: jint = -3;
pub const KEY_ESC: jint = -4;
pub const KEY_LEFT: jint = -5;
pub const KEY_RIGHT: jint = -6;

#[no_mangle]
pub extern "system" fn Java_app_speaknote_ime_chewing_ChewingNative_nativeHandleKey(
    _env: JNIEnv,
    _class: JClass,
    p: jlong,
    key: jint,
) {
    let c = ctx(p);
    unsafe {
        match key {
            KEY_SPACE => chewing_handle_Space(c),
            KEY_BACKSPACE => chewing_handle_Backspace(c),
            KEY_ENTER => chewing_handle_Enter(c),
            KEY_ESC => chewing_handle_Esc(c),
            KEY_LEFT => chewing_handle_Left(c),
            KEY_RIGHT => chewing_handle_Right(c),
            k => chewing_handle_Default(c, k),
        };
    }
}

/// Returns pending committed text (and acknowledges it), or "" if none.
#[no_mangle]
pub extern "system" fn Java_app_speaknote_ime_chewing_ChewingNative_nativeTakeCommit(
    mut env: JNIEnv,
    _class: JClass,
    p: jlong,
) -> jstring {
    let c = ctx(p);
    let s = unsafe {
        if chewing_commit_Check(c) == 1 {
            let s = cstr_to_string(chewing_commit_String_static(c));
            chewing_ack(c);
            s
        } else {
            String::new()
        }
    };
    new_jstring(&mut env, &s)
}

#[no_mangle]
pub extern "system" fn Java_app_speaknote_ime_chewing_ChewingNative_nativePreedit(
    mut env: JNIEnv,
    _class: JClass,
    p: jlong,
) -> jstring {
    let s = cstr_to_string(unsafe { chewing_buffer_String_static(ctx(p)) });
    new_jstring(&mut env, &s)
}

#[no_mangle]
pub extern "system" fn Java_app_speaknote_ime_chewing_ChewingNative_nativeBopomofo(
    mut env: JNIEnv,
    _class: JClass,
    p: jlong,
) -> jstring {
    let s = cstr_to_string(unsafe { chewing_bopomofo_String_static(ctx(p)) });
    new_jstring(&mut env, &s)
}

#[no_mangle]
pub extern "system" fn Java_app_speaknote_ime_chewing_ChewingNative_nativeCursor(
    _env: JNIEnv,
    _class: JClass,
    p: jlong,
) -> jint {
    unsafe { chewing_cursor_Current(ctx(p)) }
}

/// Commits whatever is in the pre-edit buffer and returns it.
#[no_mangle]
pub extern "system" fn Java_app_speaknote_ime_chewing_ChewingNative_nativeCommitPreedit(
    mut env: JNIEnv,
    _class: JClass,
    p: jlong,
) -> jstring {
    let c = ctx(p);
    let s = unsafe {
        chewing_clean_bopomofo_buf(c);
        if chewing_buffer_Len(c) > 0 {
            chewing_commit_preedit_buf(c);
        }
        let s = if chewing_commit_Check(c) == 1 {
            cstr_to_string(chewing_commit_String_static(c))
        } else {
            String::new()
        };
        chewing_ack(c);
        s
    };
    new_jstring(&mut env, &s)
}

/// Upper bound on candidates returned per key press. Single syllables can have
/// a few hundred homophones; the expanded 4-column grid shows all of them
/// (the horizontal strip only builds views for the first few dozen).
const MAX_CANDIDATES: usize = 400;

/// Enables / disables libchewing's automatic learning of typed phrases into
/// the user database (disabled for password and incognito fields).
#[no_mangle]
pub extern "system" fn Java_app_speaknote_ime_chewing_ChewingNative_nativeSetAutoLearn(
    _env: JNIEnv,
    _class: JClass,
    p: jlong,
    enabled: jboolean,
) {
    // chewing_set_autoLearn sets "disable_auto_learn_phrase": 0 = learn, 1 = don't.
    let mode = if enabled == JNI_FALSE { 1 } else { 0 };
    unsafe { chewing_set_autoLearn(ctx(p), mode) };
}

/// Lists candidates for the phrase at the cursor, across every phrase length
/// libchewing offers (at most MAX_CANDIDATES, in libchewing's order). Each
/// element is "<listIndex>\t<candidate>".
#[no_mangle]
pub extern "system" fn Java_app_speaknote_ime_chewing_ChewingNative_nativeCandidates(
    mut env: JNIEnv,
    _class: JClass,
    p: jlong,
) -> jobjectArray {
    let c = ctx(p);
    let mut out: Vec<String> = Vec::new();
    unsafe {
        if chewing_bopomofo_Check(c) == 0 && chewing_buffer_Len(c) > 0 && chewing_cand_open(c) == 0
        {
            chewing_cand_list_first(c);
            let mut list = 0;
            'outer: loop {
                let total = chewing_cand_TotalChoice(c);
                for i in 0..total {
                    if out.len() >= MAX_CANDIDATES {
                        break 'outer;
                    }
                    let s = cstr_to_string(chewing_cand_string_by_index_static(c, i));
                    if !s.is_empty() {
                        out.push(format!("{list}\t{s}"));
                    }
                }
                if list >= 8 || chewing_cand_list_has_next(c) != 1 {
                    break;
                }
                if chewing_cand_list_next(c) != 0 {
                    break;
                }
                list += 1;
            }
            chewing_cand_close(c);
        }
    }
    let cls = match env.find_class("java/lang/String") {
        Ok(c) => c,
        Err(_) => return ptr::null_mut(),
    };
    let arr = match env.new_object_array(out.len() as i32, cls, JObject::null()) {
        Ok(a) => a,
        Err(_) => return ptr::null_mut(),
    };
    for (i, s) in out.iter().enumerate() {
        if let Ok(js) = env.new_string(s) {
            let _ = env.set_object_array_element(&arr, i as i32, js);
        }
    }
    arr.into_raw()
}

/// Selects candidate `index` from candidate list `list` (see nativeCandidates).
#[no_mangle]
pub extern "system" fn Java_app_speaknote_ime_chewing_ChewingNative_nativeChoose(
    _env: JNIEnv,
    _class: JClass,
    p: jlong,
    list: jint,
    index: jint,
) -> jboolean {
    let c = ctx(p);
    unsafe {
        if chewing_cand_open(c) != 0 {
            return JNI_FALSE;
        }
        chewing_cand_list_first(c);
        for _ in 0..list {
            if chewing_cand_list_next(c) != 0 {
                chewing_cand_close(c);
                return JNI_FALSE;
            }
        }
        if chewing_cand_choose_by_index(c, index) == 0 {
            JNI_TRUE
        } else {
            chewing_cand_close(c);
            JNI_FALSE
        }
    }
}
