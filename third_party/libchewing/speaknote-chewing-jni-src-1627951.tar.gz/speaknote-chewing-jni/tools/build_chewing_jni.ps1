# Cross-compiles native/chewing-jni for arm64-v8a and copies the .so into
# app/src/main/jniLibs. Sets env vars only for this process.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$sdk = if ($env:ANDROID_HOME) { $env:ANDROID_HOME } else { "$env:LOCALAPPDATA\Android\Sdk" }
$ndk = Join-Path $sdk 'ndk\27.0.12077973'
$bin = Join-Path $ndk 'toolchains\llvm\prebuilt\windows-x86_64\bin'
if (-not (Test-Path $bin)) { throw "NDK not found: $ndk" }

$env:Path = "$env:USERPROFILE\.cargo\bin;" + $env:Path
$env:CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER = Join-Path $bin 'aarch64-linux-android28-clang.cmd'
$env:CC_aarch64_linux_android = Join-Path $bin 'aarch64-linux-android28-clang.cmd'
$env:AR_aarch64_linux_android = Join-Path $bin 'llvm-ar.exe'
# 16 KB ELF segment alignment (same as the sherpa-onnx .so files) so the
# library also loads on 16 KB page-size devices.
$env:CARGO_TARGET_AARCH64_LINUX_ANDROID_RUSTFLAGS = '-C link-arg=-Wl,-z,max-page-size=16384'

Push-Location (Join-Path $root 'native\chewing-jni')
try {
    $ErrorActionPreference = 'Continue'
    cargo build --release --target aarch64-linux-android 2>&1 | ForEach-Object { "$_" }
    $ErrorActionPreference = 'Stop'
    if ($LASTEXITCODE -ne 0) { throw "cargo build failed" }
} finally { Pop-Location }

$out = Join-Path $root 'app\src\main\jniLibs\arm64-v8a'
New-Item -ItemType Directory -Force $out | Out-Null
Copy-Item (Join-Path $root 'native\chewing-jni\target\aarch64-linux-android\release\libchewing_jni.so') $out -Force
Get-Item (Join-Path $out 'libchewing_jni.so') | Select-Object FullName, Length
