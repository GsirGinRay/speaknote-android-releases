"""Builds the 首注音 (abbreviated zhuyin) index for the keyboard.

Reads libchewing phrase sources ("<phrase> <freq> <bopomofo...>": tsi.src,
word.src, SpeakNote's extra .src files), drops the tones and writes a
syllable trie that the keyboard searches with partial / first-symbol input
(ㄨㄇ -> 我們). Same phrase + same toneless reading: tone variants are summed
within a source; across sources the larger value wins (extra words override).

Binary layout (big-endian), read by app/.../chewing/AbbrevIndex.kt:

    "SNAB" int version
    int S, S x (u8 len, UTF-8 toneless syllable)       sorted by string
    int N, short[N] edge syllable of each node (root = -1)
    int[N+1] childStart    children of node n are nodes childStart[n]..childStart[n+1]-1 (BFS order)
    int[N+1] phraseStart   phrases ending at node n, most frequent first
    int P, int[P] freq, int[P+1] textStart, int C, char[C] UTF-16 text
    long total frequency

Single characters in libchewing's tsi.src carry ordering values rather than
real frequencies (每 37565 / 鎂 37564, 苤 30692 > 品 20237), so for that file
each character's value is checked against how often it occurs (with that
reading) inside multi-character phrases of the same file:

    freq = min(value, sqrt(value * max(phrase_evidence, value / 20)))

Characters that are really common keep their value; rare characters that only
sit next to a common one in libchewing's ordering drop a lot. Particles that
rarely occur inside phrases (呢 嗎 吧) are kept by abbrev-extra.src entries.

Usage: python -I gen_abbrev_index.py [--dump-chars FILE] OUT.bin tsi.src word.src [extra.src ...]
"""
import math
import os
import struct
import sys
from collections import deque

TONES = str.maketrans("", "", "ˊˇˋ˙")
VERSION = 1


def is_cjk(ch: str) -> bool:
    cp = ord(ch)
    return 0x3400 <= cp <= 0x9FFF or 0xF900 <= cp <= 0xFAFF or 0x20000 <= cp <= 0x3134F


def is_bopomofo(s: str) -> bool:
    return bool(s) and all(0x3105 <= ord(c) <= 0x3129 for c in s)


def read_source(path: str) -> dict:
    out: dict[tuple, int] = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            parts = line.split()
            if len(parts) < 3 or parts[0].startswith("#"):
                continue
            phrase = parts[0]
            syls = tuple(s.translate(TONES) for s in parts[2:])
            if len(phrase) != len(syls) or not all(is_cjk(c) for c in phrase):
                continue
            if not all(is_bopomofo(s) for s in syls):
                continue
            try:
                n = max(0, int(parts[1]))
            except ValueError:
                continue
            key = (phrase, syls)
            out[key] = out.get(key, 0) + n
    return out


def adjust_single_characters(entries: dict) -> dict:
    """tsi.src only: replaces single-character ordering values by an estimate
    backed by phrase evidence (see module docstring)."""
    evidence: dict[tuple, int] = {}
    for (phrase, syls), n in entries.items():
        if len(phrase) < 2:
            continue
        for ch, s in zip(phrase, syls):
            evidence[(ch, s)] = evidence.get((ch, s), 0) + n
    out = {}
    for key, n in entries.items():
        phrase, syls = key
        if len(phrase) == 1 and n > 0:
            ev = evidence.get((phrase, syls[0]), 0)
            n = min(n, round(math.sqrt(n * max(ev, n / 20))))
        out[key] = n
    return out


def main() -> int:
    args = sys.argv[1:]
    dump = None
    if len(args) >= 2 and args[0] == "--dump-chars":
        dump, args = args[1], args[2:]
    if len(args) < 3:
        print(__doc__)
        return 2
    out_path, sources = args[0], args[1:]
    merged: dict[tuple, int] = {}
    for src in sources:
        entries = read_source(src)
        if os.path.basename(src) == "tsi.src":
            entries = adjust_single_characters(entries)
        for key, n in entries.items():
            if n > merged.get(key, -1):
                merged[key] = n

    if dump:
        # Top 10 single characters per first symbol (regression check of the frequencies).
        firsts: dict[str, list] = {}
        for (phrase, syls), n in merged.items():
            if len(phrase) == 1:
                firsts.setdefault(syls[0][0], []).append((n, phrase))
        with open(dump, "w", encoding="utf-8") as f:
            for sym in sorted(firsts):
                best: dict[str, int] = {}
                for n, ch in firsts[sym]:
                    best[ch] = max(best.get(ch, 0), n)
                top = sorted(best.items(), key=lambda t: (-t[1], t[0]))[:10]
                f.write(f"{sym} " + "、".join(ch for ch, _ in top) + "\n")

    syllables = sorted({s for (_, syls) in merged for s in syls})
    sid = {s: i for i, s in enumerate(syllables)}

    # Trie over syllable ids.
    root: dict = {"c": {}, "p": []}
    for (phrase, syls), n in merged.items():
        node = root
        for s in syls:
            node = node["c"].setdefault(sid[s], {"c": {}, "p": []})
        node["p"].append((n, phrase))

    # BFS numbering: children of each node get consecutive ids.
    order = [(-1, root)]
    queue = deque([root])
    child_start = []
    while queue:
        node = queue.popleft()
        child_start.append(len(order))
        for s in sorted(node["c"]):
            child = node["c"][s]
            order.append((s, child))
            queue.append(child)
    child_start.append(len(order))

    freqs, texts, phrase_start = [], [], []
    for _, node in order:
        phrase_start.append(len(freqs))
        for n, phrase in sorted(node["p"], key=lambda t: (-t[0], t[1])):
            freqs.append(n)
            texts.append(phrase)
    phrase_start.append(len(freqs))

    text_start, chars = [], []
    for t in texts:
        text_start.append(len(chars))
        units = t.encode("utf-16-be")
        chars.extend(struct.unpack(f">{len(units) // 2}H", units))
    text_start.append(len(chars))

    N, P = len(order), len(freqs)
    with open(out_path, "wb") as f:
        f.write(b"SNAB" + struct.pack(">i", VERSION))
        f.write(struct.pack(">i", len(syllables)))
        for s in syllables:
            b = s.encode("utf-8")
            f.write(struct.pack(">B", len(b)) + b)
        f.write(struct.pack(">i", N))
        f.write(struct.pack(f">{N}h", *[s for s, _ in order]))
        f.write(struct.pack(f">{N + 1}i", *child_start))
        f.write(struct.pack(f">{N + 1}i", *phrase_start))
        f.write(struct.pack(">i", P))
        f.write(struct.pack(f">{P}i", *freqs))
        f.write(struct.pack(f">{P + 1}i", *text_start))
        f.write(struct.pack(">i", len(chars)))
        f.write(struct.pack(f">{len(chars)}H", *chars))
        f.write(struct.pack(">q", sum(freqs)))
    print(f"{len(syllables)} syllables, {N} nodes, {P} phrases -> {out_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
